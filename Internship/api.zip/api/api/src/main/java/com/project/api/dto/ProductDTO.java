//package com.project.api.dto;
//
//public class ProductDTO {
//    private Long id;
//    private String title;
//    private ProductStockDTO productStock;
//    private ProductDetailsDTO productDetails;
//
//    // Getters and setters
//
//    public Long getId() {
//        return id;
//    }
//
//    public void setId(Long id) {
//        this.id = id;
//    }
//
//    public String getTitle() {
//        return title;
//    }
//
//    public void setTitle(String title) {
//        this.title = title;
//    }
//
//    public ProductStockDTO getProductStock() {
//        return productStock;
//    }
//
//    public void setProductStock(ProductStockDTO productStock) {
//        this.productStock = productStock;
//    }
//
//    public ProductDetailsDTO getProductDetails() {
//        return productDetails;
//    }
//
//    public void setProductDetails(ProductDetailsDTO productDetails) {
//        this.productDetails = productDetails;
//    }
//}
