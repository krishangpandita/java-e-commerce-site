document.getElementById('login-form').addEventListener('submit', function(event) {
    event.preventDefault();

    const loginData = {
        email: document.getElementById('email').value,
        password: document.getElementById('password').value
    };

    fetch('/api/products/login', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(loginData)
    })
    .then(response => {
        if (!response.ok) {
            return response.json().then(err => { throw err; }).catch(() => { throw new Error(response.statusText); });
        }
        return response.json();
    })
    .then(data => {
        console.log('User logged in:', data);
        alert('Login successful!');
        window.location.href = 'index.html'; // Redirect to the main page
    })
    .catch(error => {
        console.error('Error logging in user:', error);
        alert('Error: ' + (error.error || error.message || 'Error logging in user'));
    });
});
