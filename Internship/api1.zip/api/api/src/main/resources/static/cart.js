document.addEventListener('DOMContentLoaded', function() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];

    if (cart.length === 0) {
        document.querySelector('#cart-table tbody').innerHTML = '<tr><td colspan="11">Your cart is empty</td></tr>';
        return;
    }

    fetch('/api/products/all')
        .then(response => response.json())
        .then(data => {
            const tableBody = document.querySelector('#cart-table tbody');
            cart.forEach(cartItem => {
                const product = data.find(p => p.id === parseInt(cartItem.id));
                if (product) {
                    const totalAmount = product.price * cartItem.quantity;
                    const row = document.createElement('tr');

                    row.innerHTML = `
                        <td>${product.title}</td>
                        <td>${product.stock || 'N/A'}</td>
                        <td>${product.price || 'N/A'}</td>
                        <td>${product.discountPercentage || 'N/A'}%</td>
                        <td>${product.rating || 'N/A'}</td>
                        <td>${product.brand || 'N/A'}</td>
                        <td><img src="${product.thumbnail}" alt="${product.title}" /></td>
                        <td>${product.images.map(image => `<img src="${image}" alt="${product.title}" />`).join('') || 'N/A'}</td>
                        <td>
                            <input type="number" class="quantity-input" data-id="${product.id}" value="${cartItem.quantity}" min="1">
                        </td>
                        <td class="total-amount" data-id="${product.id}">${totalAmount}</td>
                        <td><button class="remove-from-cart" data-id="${product.id}">Remove from Cart</button></td>
                    `;

                    tableBody.appendChild(row);
                }
            });

            document.querySelectorAll('.quantity-input').forEach(input => {
                input.addEventListener('change', function() {
                    const productId = this.getAttribute('data-id');
                    const newQuantity = parseInt(this.value);
                    updateCart(productId, newQuantity);
                });
            });

            document.querySelectorAll('.remove-from-cart').forEach(button => {
                button.addEventListener('click', function() {
                    const productId = this.getAttribute('data-id');
                    removeFromCart(productId);
                });
            });
        })
        .catch(error => {
            console.error('Error fetching data:', error);
        });
});

function updateCart(productId, newQuantity) {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart = cart.map(item => {
        if (item.id === productId) {
            item.quantity = newQuantity;
        }
        return item;
    });
    localStorage.setItem('cart', JSON.stringify(cart));
    alert('Cart updated!');
    location.reload();
}

function removeFromCart(productId) {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    cart = cart.filter(item => item.id !== productId);
    localStorage.setItem('cart', JSON.stringify(cart));
    alert('Product removed from cart!');
    location.reload();
}
