package com.project.api.repository;

import com.project.api.entity.ProductMain;
import com.project.api.dto.ProductDTO;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import java.util.List;

public interface ProductMainRepository extends JpaRepository<ProductMain, Long> {

    List<ProductMain> findByTitleContaining(String title);
}



