package com.project.api.controller;

import com.project.api.dto.ProductDTO;
import com.project.api.entity.ProductMain;
import com.project.api.exception.ResourceNotFoundException;
import com.project.api.request.ProductRequest;
import com.project.api.response.ProductResponse;
import com.project.api.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.List;

@RestController
@RequestMapping("/api/products")
public class ProductAPIController {

    @Autowired
    private final ProductService productService;

    public ProductAPIController(ProductService productService) {
        this.productService = productService;
    }

    @GetMapping("/all")
    public ResponseEntity<List<ProductResponse>> getAllProducts() {
        List<ProductResponse> products = productService.getAllProducts();
        return ResponseEntity.ok(products);
    }

    @GetMapping("/{productId}")
    public ResponseEntity<ProductResponse> getProductById(@PathVariable Long productId) {
        ProductResponse product = productService.findProductById(productId);
        if (product == null) {
            throw new ResourceNotFoundException("Product with ID " + productId + " not found");
        }
        return ResponseEntity.ok(product);
    }

//    @GetMapping("/search")
//    public ResponseEntity<List<ProductResponse>> searchProducts(@RequestParam String query) {
//        List<ProductResponse> responses = productService.searchProducts(query);
//        return ResponseEntity.ok(responses);
//    }
    @PostMapping
    public ResponseEntity<ProductResponse> createProduct(@Valid @RequestBody ProductRequest request) {
        ProductResponse response = productService.createProductMain(request);
        return ResponseEntity.ok(response);
    }

    @PutMapping("/{productId}")
    public ResponseEntity<ProductResponse> updateProduct(@PathVariable Long productId, @Valid @RequestBody ProductRequest request) {
        ProductResponse existingProduct = productService.findProductById(productId);
        if (existingProduct == null) {
            throw new ResourceNotFoundException("Product with ID " + productId + " not found");
        }
        request.setId(productId); // Ensure the ID is set in the request
        ProductResponse updatedProduct = productService.updateProductMain(request);
        return ResponseEntity.ok(updatedProduct);
    }

    @DeleteMapping("/{productId}")
    public ResponseEntity<String> deleteProduct(@PathVariable Long productId) {
        ProductResponse product = productService.findProductById(productId);
        if (product == null) {
            throw new ResourceNotFoundException("Product with ID " + productId + " not found");
        }
        productService.deleteProductMain(productId);
        return ResponseEntity.ok("Product Deleted Successfully");
    }

    @GetMapping
    public ResponseEntity<List<ProductResponse>> searchProducts(
            @RequestParam(value = "title", required = false) String title,
            @RequestParam(value = "brand", required = false) String brand) {
        if (title != null && !title.isEmpty()) {
            return ResponseEntity.ok(productService.searchProductsByTitle(title));
        } else if (brand != null && !brand.isEmpty()) {
            return ResponseEntity.ok(productService.searchProductsByBrand(brand));
        } else {
            return ResponseEntity.ok(productService.getAllProducts());
        }
    }
}
