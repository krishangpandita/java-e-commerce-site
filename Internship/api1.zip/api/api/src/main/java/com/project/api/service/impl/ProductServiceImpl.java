package com.project.api.service.impl;

import com.project.api.entity.ProductDetails;
import com.project.api.entity.ProductMain;
import com.project.api.entity.ProductStock;
import com.project.api.repository.ProductDetailsRepository;
import com.project.api.repository.ProductMainRepository;
import com.project.api.repository.ProductStockRepository;
import com.project.api.request.ProductRequest;
import com.project.api.response.ProductResponse;
import com.project.api.service.ProductService;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;
import java.util.stream.IntStream;

@Service
public class ProductServiceImpl implements ProductService {
    @Autowired
    private ProductMainRepository productMainRepo;
    @Autowired
    private ProductStockRepository productStockRepo;
    @Autowired
    private ProductDetailsRepository productDetailsRepo;

    @Override
    public List<ProductResponse> getAllProducts() {
// Fetch all products, details, and stocks
        List<ProductMain> products = productMainRepo.findAll();
        List<ProductDetails> details = productDetailsRepo.findAll();
        List<ProductStock> stocks = productStockRepo.findAll();

        List<ProductResponse> responses = IntStream.range(0, Math.min(products.size(), Math.min(details.size(), stocks.size())))
                .mapToObj(i -> {
                    ProductMain product = products.get(i);
                    ProductDetails detail = details.get(i);
                    ProductStock stock = stocks.get(i);

                    ProductResponse response = new ProductResponse();
                    response.setId(product.getId());
                    response.setTitle(product.getTitle());
                    response.setPrice(detail.getPrice());
                    response.setRating(detail.getRating());
                    response.setStock(stock.getStock());
                    response.setDiscountPercentage(detail.getDiscountPercentage());
                    response.setBrand(detail.getBrand());
                    response.setThumbnail(detail.getThumbnail());
                    response.setImages(detail.getImages());

                    return response;
                })
                .collect(Collectors.toList());

        return responses;
    }

    @Override
    public ProductResponse findProductById(Long id) {
        ProductMain product = productMainRepo.findById(id).orElse(null);
        ProductDetails detail = productDetailsRepo.findById(id).orElse(null);
        ProductStock stock = productStockRepo.findById(id).orElse(null);

        if (product != null && detail != null && stock != null) {
            ProductResponse response = new ProductResponse();
            response.setId(product.getId());
            response.setTitle(product.getTitle());
            response.setPrice(detail.getPrice());
            response.setRating(detail.getRating());
            response.setStock(stock.getStock());
            response.setDiscountPercentage(detail.getDiscountPercentage());
            response.setBrand(detail.getBrand());
            response.setThumbnail(detail.getThumbnail());
            response.setImages(detail.getImages());
            return response;
        }
//        } else {
//            return null;
//        }
            return null;
    }


    //
//    @Override
//    public List<ProductDTO> getAllProducts() {
//        return productMainRepository.findAll().stream()
//                .map(this::convertToDTO)
//                .collect(Collectors.toList());
//    }
//
//    @Override
//    public ProductDTO findProductById(Long id) {
//        ProductMain productMain = productMainRepository.findById(id).orElseThrow(() -> new RuntimeException("Product not found"));
//        return convertToDTO(productMain);
//    }
//
//    @Override
//    public ProductDTO createProductMain(ProductMain productMain) {
//        ProductMain savedProductMain = productMainRepository.save(productMain);
//        return convertToDTO(savedProductMain);
//    }
//
//    @Override
//    public ProductDTO updateProductMain(ProductMain productMain) {
//        ProductMain updatedProductMain = productMainRepository.save(productMain);
//        return convertToDTO(updatedProductMain);
//    }
//
//    @Override
//    public void deleteProductMain(Long productId) {
//        productMainRepository.deleteById(productId);
//    }
//
//    private ProductDTO convertToDTO(ProductMain productMain) {
//        ProductDTO productDTO = new ProductDTO();
//        productDTO.setId(productMain.getId());
//        productDTO.setTitle(productMain.getTitle());
//
//        ProductStock productStock = productMain.getProductStock();
//        if (productStock != null) {
//            ProductStockDTO productStockDTO = new ProductStockDTO();
//            productStockDTO.setId(productStock.getId());
//            productStockDTO.setStock(productStock.getStock());
//            productDTO.setProductStock(productStockDTO);
//        }
//
//        ProductDetails productDetails = productMain.getProductDetails();
//        if (productDetails != null) {
//            ProductDetailsDTO productDetailsDTO = new ProductDetailsDTO();
//            productDetailsDTO.setId(productDetails.getId());
//            productDetailsDTO.setPrice(productDetails.getPrice());
//            productDetailsDTO.setDiscountPercentage(productDetails.getDiscountPercentage());
//            productDetailsDTO.setRating(productDetails.getRating());
//            productDetailsDTO.setBrand(productDetails.getBrand());
//            productDetailsDTO.setThumbnail(productDetails.getThumbnail());
//            productDetailsDTO.setImages(productDetails.getImages());
//            productDTO.setProductDetails(productDetailsDTO);
//        }
//
//        return productDTO;
//    }
    @Override
    public ProductResponse createProductMain(ProductRequest request){
        ProductMain product = new ProductMain();
        ProductDetails details =  new ProductDetails();
        ProductStock stock = new ProductStock();
        BeanUtils.copyProperties(request,product);
        BeanUtils.copyProperties(request,details);
        BeanUtils.copyProperties(request,stock);
        ProductMain main = productMainRepo.save(product);
        productDetailsRepo.save(details);
        productStockRepo.save(stock);
        ProductResponse response = new ProductResponse();
        response.setId(main.getId());
        response.setTitle(main.getTitle());
        response.setBrand(details.getBrand());
        response.setPrice(details.getPrice());
        response.setRating(details.getRating());
        response.setStock(stock.getStock());
        response.setDiscountPercentage(details.getDiscountPercentage());
        response.setBrand(details.getBrand());
        response.setThumbnail(details.getThumbnail());
        response.setImages(details.getImages());

        return response;
    }

    @Override
    public ProductResponse updateProductMain(ProductRequest request) {
        ProductMain product = productMainRepo.findById(request.getId()).orElse(null);
        if (product == null) return null;

        ProductDetails details = productDetailsRepo.findById(request.getId()).orElse(null);
        ProductStock stock = productStockRepo.findById(request.getId()).orElse(null);

        BeanUtils.copyProperties(request, product);
        BeanUtils.copyProperties(request, details);
        BeanUtils.copyProperties(request, stock);

        productMainRepo.save(product);
        productDetailsRepo.save(details);
        productStockRepo.save(stock);

        ProductResponse response = new ProductResponse();
        response.setId(product.getId());
        response.setTitle(product.getTitle());
        response.setPrice(details.getPrice());
        response.setRating(details.getRating());
        response.setStock(stock.getStock());
        response.setDiscountPercentage(details.getDiscountPercentage());
        response.setBrand(details.getBrand());
        response.setThumbnail(details.getThumbnail());
        response.setImages(details.getImages());

        return response;
    }


    @Override
    public void deleteProductMain(Long productId) {
        productMainRepo.deleteById(productId);
        productDetailsRepo.deleteById(productId);
        productStockRepo.deleteById(productId);
    }
    @Override
    public List<ProductResponse> searchProductsByTitle(String title) {
        List<ProductMain> products = productMainRepo.findByTitleContaining(title);
        return products.stream().map(this::convertToProductResponse).collect(Collectors.toList());
    }

    @Override
    public List<ProductResponse> searchProductsByBrand(String brand) {
        List<ProductDetails> details = productDetailsRepo.findByBrandContaining(brand);
        return details.stream().map(detail -> {
            ProductMain product = productMainRepo.findById(detail.getId()).orElse(null);
            return convertToProductResponse(product, detail);
        }).collect(Collectors.toList());
    }

    private ProductResponse convertToProductResponse(ProductMain product) {
        ProductDetails detail = productDetailsRepo.findById(product.getId()).orElse(null);
        ProductStock stock = productStockRepo.findById(product.getId()).orElse(null);
        return convertToProductResponse(product, detail, stock);
    }

    private ProductResponse convertToProductResponse(ProductMain product, ProductDetails detail) {
        ProductStock stock = productStockRepo.findById(product.getId()).orElse(null);
        return convertToProductResponse(product, detail, stock);
    }

    private ProductResponse convertToProductResponse(ProductMain product, ProductDetails detail, ProductStock stock) {
        ProductResponse response = new ProductResponse();
        response.setId(product.getId());
        response.setTitle(product.getTitle());
        if (detail != null) {
            response.setPrice(detail.getPrice());
            response.setRating(detail.getRating());
            response.setDiscountPercentage(detail.getDiscountPercentage());
            response.setBrand(detail.getBrand());
            response.setThumbnail(detail.getThumbnail());
            response.setImages(detail.getImages());
        }
        if (stock != null) {
            response.setStock(stock.getStock());
        }
        return response;
    }

    @Override
    public List<ProductResponse> searchProducts(String query) {
        List<ProductMain> products = productMainRepo.findByTitleContaining(query);
        List<ProductDetails> details = productDetailsRepo.findByBrandContaining(query);

        List<ProductResponse> responses = IntStream.range(0, Math.max(products.size(), details.size()))
                .mapToObj(i -> {
                    ProductResponse response = new ProductResponse();
                    if (i < products.size()) {
                        ProductMain product = products.get(i);
                        response.setId(product.getId());
                        response.setTitle(product.getTitle());
                    }
                    if (i < details.size()) {
                        ProductDetails detail = details.get(i);
                        response.setPrice(detail.getPrice());
                        response.setRating(detail.getRating());
                        response.setDiscountPercentage(detail.getDiscountPercentage());
                        response.setBrand(detail.getBrand());
                        response.setThumbnail(detail.getThumbnail());
                        response.setImages(detail.getImages());
                    }
                    return response;
                })
                .collect(Collectors.toList());

        return responses;
    }
}
